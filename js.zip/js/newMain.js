
//if basic graph settings==configRow and if free graph settings==form
async function buildNetworkGraph(settingsGraph,branchType,node,configClasses){
    let sparqlQuery=getQuery()
    hideSpinMessage(interval)
    //console.log(settingsGraph)
    //console.log(branchType)
    //console.log(node)
    var interval=showSpinMessage("Waiting for Sparql query")
    let prefixes=""
    let queryUrl = settingsGraph.url + "?query=" + prefixes +  encodeURIComponent(  sparqlQuery  )+ "&format=json";
    let settings = { url: queryUrl, async: true   , dataType: 'jsonp'     };

    $objectAjax=$.ajax(settings).then  (function( _data ) {
        var results = _data.results.bindings;

        //stop displaing message when executing query
        hideSpinMessage(interval)

        buildData(branchType,results, settingsGraph, node,configClasses)
        
        //if no bubble is clicked or row in the table
        if(node==undefined){
          //remove a graph if in there is one
          //d3.selectAll(".graph").remove()

          //get data from results in query
          /* if(branchType=="basic"){
            data=buildDataBasic(results,configRow,configClasses,node)
          }else if(branchType=="expert"){
            data=buildDataExpert()
          } */
          // if there is no node the type is basic
          
/*           if(branchType=="basic"){
            data=buildDataBasic(results,configRow,configClasses,node)
          }else if(branchType=="expert"){
            $("#myModal3").hide();
            //console.log(results)
            data=buildDataExpert(results, settingsGraph, node)
            //console.log(data) */
/*             if(settings.origin=="bubble"){
              addNodesGraph(results, node, form)
            }else{
              data=buildDataExpert(results, form, node)
            } */
          //}
          //data=buildDataBasic(results,configRow,configClasses,node)
          //add forces to graph
          setForcesGraph()

          //check if there is an object networkGraph already
          if(networkGraph){
            console.log("networkGraph")
            legend.deleteAllColors()
          }else{
            console.log("no networkGraph")
            d3.selectAll(".graph").remove()
            networkGraph = new NetworkGraph("#networkGraph", data,forces,"fromConfig");
            legend=new Legend("legend")
          }

          collapse(networkGraph.treeData[0])
        }else{
          //add information for centering the graph
          networkGraph.addingGraph=true
          networkGraph.dblClickId=node.id.replace("_image","")+"_g"

          //build data for the graph
          //buildDataBasic(results,configRow,configClasses,node)
/*           if(branchType=="basic"){
            data=buildDataBasic(results,configRow,configClasses,node)
          }else if(branchType=="expert"){
              //if(settings.origin=="bubble"){
              //  addNodesGraph(results, node, form)
              //}else{
            data=buildDataExpert(results, settingsGraph, node)
              //}
          } */
          networkGraph.data=flatten(networkGraph.treeData).flatData

          networkGraph.refresh()

          legend.addColors(colorScale)
          handleNavigation(node)

          //collapse graph if is basic type and hierarchy has more than two levels
          if(branchType=="basic"){
            if(settingsGraph.hierarchy.length>1){
                collapse(networkGraph.treeData.filter(d=>d.id==node.id)[0])
            }
          }
        }

      })
      //.fail(function (jqXHR, textStatus, errorThrown) {
      //  document.getElementById("sparql-timeout").style.display="inline-block"
      //})
      .always(function(jqXHR, textStatus, errorThrown) {
        hideSpinMessage(interval)
      })
      .done(function (data, textStatus, jqXHR) {
        //clearInterval(interval)
        //d3.select("#spin").style("display","none")
        //document.getElementById("sparql-timeout").style.display="none"
        hideSpinMessage(interval)

        /* if(node){
          var transform=document.getElementsByClassName("gMain")[0].getAttribute("transform")
          if(transform){
            translate = transform.substring(transform.indexOf("(")+1, transform.indexOf(")")).split(",");
          }
          var dcx = (window.innerWidth/2+d3.select("#"+node.id+"_g").data()[0]["x"]);
          var dcy = (window.innerHeight/2+d3.select("#"+node.id+"_g").data()[0]["y"]);

          var p = $( "#"+node.id );
          var position = p.position();

          networkGraph.graphAdded=true

        } */

      })
      await $objectAjax

    function getQuery(){
      var sparqlQuery;
      if(branchType=="basic"){
          if (node){
              sparqlQuery=replaceParmtrsQuery(settingsGraph,node)
          }else{
              sparqlQuery=settingsGraph.sparqlQuery
          }
      }else if(branchType=="expert"){
          sparqlQuery=buildExpertQuery()
      }
      return sparqlQuery
    }

    function buildExpertQuery(){
        //form = { "uri": uri, "url": url, "subject-object": subjectObject }
        var sparqlQuery;
        if (settingsGraph["subject-object"] == "s") {
            sparqlQuery = "SELECT distinct ?s ?p ?o WHERE{{ ?s ?p ?o.} FILTER (?s=<" + settingsGraph["uri"]+ ">).}"
        } else {
            sparqlQuery = "SELECT distinct ?s ?p ?o WHERE{{ ?s ?p ?o.} FILTER (?o=<" + settingsGraph["uri"] + ">).}"
        }
        return sparqlQuery
    }

    /* function replaceParmtrsQuery(settingsGraph,node){
      var sparqlQuery;
      if(settingsGraph.parameters!=""){
        let parameters=get_parameters(settingsGraph.parameters)
        for (let i = 0; i < parameters.length; ++i) { 
          sparqlQuery=settingsGraph.sparqlQuery.replaceAll("PARAMETER"+(i+2).toString(), node[parameters[i]]);
        }  
        //The value for the PARAMETER in the Sparql query is the "[class]_uri" or the
        //name of the class with no "_uri"

        if((node[node["class"]+"_uri"]!=undefined)&&(node[node["class"]+"_uri"]!="")){
          sparqlQuery=sparqlQuery.replaceAll("PARAMETER", node[node["class"]+"_uri"]);
        }else{
          sparqlQuery=sparqlQuery.replaceAll("PARAMETER", node["value"]);
        }
      }else{
        //if(node["configRow"]){
        //  sparqlQuery=settingsGraph.sparqlQuery.replaceAll("PARAMETER", node["value"]);
        //}else{
        sparqlQuery=settingsGraph.sparqlQuery.replaceAll("PARAMETER", node[node["class"]+"_uri"]);
        //}        
      }
      return sparqlQuery
    } */

    function setForcesGraph(){
      forces = {
        center: {
            x: 0.5,
            y: 0.5
        },
        charge: {
            enabled: true,
            strength: -800,
            distanceMin: 100,
            distanceMax: 2000
        },
        collide: {
            enabled: false,
            strength: .2,
            iterations: 1,
            radius: 5
        },
        forceX: {
            enabled:true,
            strength: .1,
            x: .2
        },
        forceY: {
            enabled: true,
            strength: .1,
            y: .2
        },
        link: {
            enabled: true,
            distance: 100,
            iterations: 1
        }
      }
    }
}
function replaceParmtrsQuery(settingsGraph,node){
  var sparqlQuery;
  if(settingsGraph.parameters!=""){
    let parameters=get_parameters(settingsGraph.parameters)
    for (let i = 0; i < parameters.length; ++i) { 
      sparqlQuery=settingsGraph.sparqlQuery.replaceAll("PARAMETER"+(i+2).toString(), node[parameters[i]]);
    }  
    //The value for the PARAMETER in the Sparql query is the "[class]_uri" or the
    //name of the class with no "_uri"

    if((node[node["class"]+"_uri"]!=undefined)&&(node[node["class"]+"_uri"]!="")){
      sparqlQuery=sparqlQuery.replaceAll("PARAMETER", node[node["class"]+"_uri"]);
    }else{
      sparqlQuery=sparqlQuery.replaceAll("PARAMETER", node["value"]);
    }
  }else{
    //if(node["configRow"]){
    //  sparqlQuery=settingsGraph.sparqlQuery.replaceAll("PARAMETER", node["value"]);
    //}else{
    sparqlQuery=settingsGraph.sparqlQuery.replaceAll("PARAMETER", node[node["class"]+"_uri"]);
    //}        
  }
  return sparqlQuery
}
function getMenuItems(items,node,pageX,pageY,origin,graphType){
  var menuItems=[],elementMenu,position
  
  if (node["configRow"]) {
    node["configRow"].forEach(function (r) {
      items.push({ "rowNumber": r, "row": configFile[r], "menuOption": configFile[r]["option"] })
    })
  }
  //if click on Navigation panel then origin=table
  if (origin=="table"){
    if(graphType=="basic"){
      tableBasic()
    }else if(graphType=="expert"){
      tableExpert()
    }
    //function that add menu items to table
    ////////console.log("antes de add...")
    addMenuToTable(node,menuItems)
  }else{
    //if click on bubble in graph, fill menu to show on screen next to bubble
    //and add action to build basic graph in case the option in the menu is clicked
    for (var i = 0; i < items.length; i++) {
      if(graphType=="basic"){
        noTableBasic()
      }else if(graphType=="expert"){
        noTableExpert()
      }
      menuItems.push(elementMenu)
    }
    console.log(menuItems)
    console.log(node)
    //Send menuItems to menuFactory which will draw the menu in the graph
    networkGraph.menuFactory(100,0, menuItems, node,"dblClick",250)
  }
  function noTableBasic(){
    console.log(items)
    position=items[i]["position"]
    elementMenu={
      title: items[i]["option"],
      action: (data,d) => {
        
        for (var i = 0; i < configFile.length; i++) {
              if(configFile[i]["option"] == d.title){
                position=i
              }
            }
        if(node.menuOption!=undefined){
          if(node.menuOption.split(";")[0]==d.title){
            networkGraph.expandLevelBranch(node)          
            networkGraph.data=flatten(networkGraph.treeData).flatData
            networkGraph.initializeSimulation();
            networkGraph.dataJoinGraph()
            networkGraph.enterGraph()
            
            networkGraph.initializeSimulation();
            networkGraph.dataJoinGraph()
            networkGraph.exitGraph()
          }else{
            buildBasicGraph(position,node,d.title)
          }
        }else{
          buildBasicGraph(position,node,d.title)
        }
      }
    }
  }
  function noTableExpert(){
    if (items[i]["subject-object"]) {
      uri = items[i]["uri"]
      url = items[i]["url"]
      subjectObject = items[i]["subject-object"]
      itemsDetails = { "uri": uri, "url": url, "subject-object": subjectObject }
      elementMenu = {
        title: "Sparql Endpoint: " + url + " and Position: " + subjectObject,
        action: (data, d) => {
          url = d.title.match("Sparql Endpoint: (.*) and Position:")[1];
          subjectObject = d.title.match("and Position: (.*)")[1];
          form = { "url": url, "uri": uri, "subject-object": subjectObject }
          //buildFreeGraph(form, origin, node)
          buildNetworkGraph(form,"expert",node)
        }
      }
    } else {
      elementMenu = {
        title: items[i]["menuOption"],
        action: (data, d) => {
          row = configFile.findIndex(v => v.option == d.title)
          buildBasicGraph(row, d3.select("#" + data.getAttribute("id")).data()[0], d.title)
        }
      }
    }
  }
  function tableExpert(){
    if (items[i]["subject-object"]) {
      menuItems.push({ "url": items[i]["url"], "uri": items[i]["uri"], "subject-object": items[i]["subject-object"] })
    }
    else {
      menuItems.push({ "rowDataConfig": items[i]["rowNumber"], "node": node, "menuOption": items[i]["menuOption"] })
    }
  }
  function tableBasic(){
    for (var i = 0; i < items.length; i++) {
      //add all items to menu in table. Get options text and line in config file
      //and add it to the table
      menuItems.push({"option":items[i]["option"],"position":items[i]["position"]})
    }
  }
}
async function checkQueries(element, subjectObject, origin, pageX, pageY) {
  var node;
  //console.log("checkQueries")
  var resultRows =await checkAskResultsFreeGraph(element, subjectObject)
  //console.log(resultRows)
  if (typeof (element) != "string") {
    node = d3.select("#" + element.getAttribute("id")).data()[0]
  }
  //if ((origin == "bubble") || (origin == "table")) {
  if (node.menuOption != undefined) {
    filterResultRows()
  }
  //}
  if (resultRows.length > 1) {
      getMenuItems(resultRows, node, pageX, pageY, origin,"expert")
  } else if (resultRows.length == 1) {
    form = resultRows[0]
    await buildFreeGraph(form, origin, node)
  } 

  return resultRows
  
/*   function filterResultRows() {
    var menuOption = node.menuOption.split(";")
    menuOption.forEach(function (d) {
      d = d.split(",")
      resultRows = resultRows.filter(function (r) {
        return (r.uri != node.value) || (r.url != d[0]) || (r["subject-object"] != d[1])
      })
    })

  } */
}
async function checkAskResults(indexRows,node){
  var sparqlQuery,resultIndexRows=[],parameters,arrayMenuOptions

  if(node.menuOption){
    arrayMenuOptions=node.menuOption.split(";")
    indexRows=indexRows.filter(d=>!arrayMenuOptions.includes(d.option))
  }

  for (var i = 0; i < indexRows.length; i++) {
    //first we transform the select to ask query
    if(configFile[indexRows[i]["position"]]["askquery"]){
      sparqlQuery=configFile[indexRows[i]["position"]]["askquery"]
    }else{
      sparqlQuery=fromSelectToAskQuery(configFile[indexRows[i]["position"]]["query"])
    }
    
    //get parameters from config file
    parameters=configFile[indexRows[i]["position"]]["parameters"]
    if(node["class"]!=undefined){
      if((parameters!="")&&(parameters!=undefined)){
        //if there are parameters we have to replace everything form the node with the
        //parameters in the config file
        parameters=get_parameters(parameters)
        for (let j = 0; j < parameters.length; ++j) { 
          sparqlQuery=sparqlQuery.replaceAll("PARAMETER"+(j+2).toString(), node[parameters[j]]);
        }  
          if((node[node["class"]+"_uri"]!=undefined)&&(node[node["class"]+"_uri"]!="")){
            sparqlQuery=sparqlQuery.replaceAll("PARAMETER",node[node["class"]+"_uri"]);

          } else{
            sparqlQuery=sparqlQuery.replaceAll("PARAMETER",node["value"]);
          }
      }else{
        if(node[node["class"]+"_uri"]!=undefined){
          sparqlQuery=sparqlQuery.replaceAll("PARAMETER",node[node["class"]+"_uri"]);
        } else{
          sparqlQuery=sparqlQuery.replaceAll("PARAMETER",node[node["value"]+"_code"]);
        }
      }
    }else{
      sparqlQuery=sparqlQuery.replaceAll(node,"PARAMETER"); 
    }
    results = await runAskSparlqQuery(configFile[indexRows[i]["position"]]["endpoint_url"],sparqlQuery)
    
    //add row to the results if there are results returned
    if(results==true){
      resultIndexRows.push(indexRows[i])
    }
  }
  //console.log(resultIndexRows)
  return resultIndexRows
}
async function checkAskResultsFreeGraph(node, so) {
  var resultRows = []

  return new Promise((resolve, reject) => {
    d3.csv("../config_vinalod/sparqlEndpoints.csv",async function(urls){
        //////console.log(urls)
        if (so == undefined) {
          subjectObject = ['s', 'o']
        } else {
          subjectObject = [so]
        }
        //console.log(subjectObject)
        //console.log(urls)
        if (typeof node === 'object') {
          uri = d3.select("#" + node.id).data()[0].value
        } else {
          uri = node
        }
        for (var j = 0; j < subjectObject.length; j++) {
          for (var i = 0; i < urls.length; i++) {
            results = await runAskSparlqQueryFreeGraph(urls[i].sparqlEndpoint, uri, subjectObject[j])
            if (results == true) {
              resultRows.push({ "url": urls[i].sparqlEndpoint, "subject-object": subjectObject[j], "uri": uri })
            }
          }
        }
      //console.log(resultRows)
      resolve(resultRows)
    })
  })
}
/* function getMenuItems(items,node,pageX,pageY,origin){
  var menuItems=[],element,position
  
  //if click on Navigation panel then origin=table
  if (origin=="table"){
    for (var i = 0; i < items.length; i++) {
      //add all items to menu in table. Get options text and line in config file
      //and add it to the table
      menuItems.push({"option":items[i]["option"],"position":items[i]["position"]})
    }
    //function that add menu items to table
    ////////console.log("antes de add...")
    addMenuToTable(node,menuItems)
  }else{
    //if click on bubble in graph, fill menu to show on screen next to bubble
    //and add action to build basic graph in case the option in the menu is clicked
    for (var i = 0; i < items.length; i++) {
      position=items[i]["position"]
      element={
        title: items[i]["option"],
        action: (data,d) => {
          
          for (var i = 0; i < configFile.length; i++) {
                if(configFile[i]["option"] == d.title){
                  position=i
                }
              }
          if(node.menuOption!=undefined){
            if(node.menuOption.split(";")[0]==d.title){
              networkGraph.expandLevelBranch(node)          
              networkGraph.data=flatten(networkGraph.treeData).flatData
              networkGraph.initializeSimulation();
              networkGraph.dataJoinGraph()
              networkGraph.enterGraph()
              
              networkGraph.initializeSimulation();
              networkGraph.dataJoinGraph()
              networkGraph.exitGraph()
            }else{
              buildBasicGraph(position,node,d.title)
            }
          }else{
            buildBasicGraph(position,node,d.title)
          }
        }
      }
      menuItems.push(element)
    }
    //Send menuItems to menuFactory which will draw the menu in the graph
    networkGraph.menuFactory(100,0, menuItems, node,"dblClick",250)
  }
}
function getMenuItemsFreeGraph(items, node, pageX, pageY, origin) {
  var menuItems = [], elementMenu,form, uri, url, subjectObject, row
  //////console.log(node)
  if (node["configRow"]) {
    node["configRow"].forEach(function (r) {
      items.push({ "rowNumber": r, "row": configFile[r], "menuOption": configFile[r]["option"] })
    })
  }

  if (origin == "table") {
    for (var i = 0; i < items.length; i++) {
      if (items[i]["subject-object"]) {
        menuItems.push({ "url": items[i]["url"], "uri": items[i]["uri"], "subject-object": items[i]["subject-object"] })
      }
      else {
        menuItems.push({ "rowDataConfig": items[i]["rowNumber"], "node": node, "menuOption": items[i]["menuOption"] })
      }
    }
    navigation.addMenuToTable(node, menuItems)
  } else {
    for (var i = 0; i < items.length; i++) {
      if (items[i]["subject-object"]) {
        uri = items[i]["uri"]
        url = items[i]["url"]
        subjectObject = items[i]["subject-object"]
        itemsDetails = { "uri": uri, "url": url, "subject-object": subjectObject }
        elementMenu = {
          title: "Sparql Endpoint: " + url + " and Position: " + subjectObject,
          action: (data, d) => {
            url = d.title.match("Sparql Endpoint: (.*) and Position:")[1];
            subjectObject = d.title.match("and Position: (.*)")[1];
            form = { "url": url, "uri": uri, "subject-object": subjectObject }
            //buildFreeGraph(form, origin, node)
            buildNetworkGraph(form,"expert",node)
          }
        }
      } else {
        elementMenu = {
          title: items[i]["menuOption"],
          action: (data, d) => {
            row = configFile.findIndex(v => v.option == d.title)
            buildBasicGraph(row, d3.select("#" + data.getAttribute("id")).data()[0], d.title)
          }
        }
      }
      menuItems.push(elementMenu)
    }
    networkGraph.menuFactory(pageX - 400, pageY - 450, menuItems, element, "dblClick", 500)
  }

} */